package com.home.run;

import com.home.controller.MemberController;

public class Main {
	public static void main(String[] args) {
		new MemberController().mainMenu();
	}
}
