package com.home2.run;

import com.home2.controller.EmployeeController;

public class Main {
	public static void main(String[] args) {
		new EmployeeController().mainMenu();
	}
}
