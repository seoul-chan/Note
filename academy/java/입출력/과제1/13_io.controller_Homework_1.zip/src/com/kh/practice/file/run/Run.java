package com.kh.practice.file.run;

import com.kh.practice.file.view.FileMenu;

public class Run {
	public static void main(String[] args) {
		FileMenu fm = new FileMenu();
		fm.mainMenu();
	}
}
