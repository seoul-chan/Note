package com.kh.practice.leap.run;

import com.kh.practice.leap.view.LeapView;

public class Run {
	public static void main(String[] args) {
		new LeapView();
	}
}
