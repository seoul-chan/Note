package music.play.list.run;

import music.play.list.view.MusicPlayer;

public class Run {
	public static void main(String[] args) {
		 new MusicPlayer().mainMenu();
	}
}
