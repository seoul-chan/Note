package com.kh.hw.person.run;

import com.kh.hw.person.view.PersonMenu;

public class Run {
	public static void main(String[] args) {
		new PersonMenu().mainMenu(); 
	}
}
