package com.kh.practice.chap01_poly.run;

import com.kh.practice.chap01_poly.model.view.LibraryMenu;

public class Run {
	public static void main(String[] args) {
		new LibraryMenu().mainMenu(); 
	}
}
