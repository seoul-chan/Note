package com.common;

import com.model.vo.Food;

public interface TestLambda {
	
	boolean test(Food f); //�߻� �޼���
}
