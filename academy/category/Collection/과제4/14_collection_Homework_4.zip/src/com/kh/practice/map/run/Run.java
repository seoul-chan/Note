package com.kh.practice.map.run;

import com.kh.practice.map.view.MemberMenu;

public class Run {
	public static void main(String[] args) {
		new MemberMenu().mainMenu();
	}
}
