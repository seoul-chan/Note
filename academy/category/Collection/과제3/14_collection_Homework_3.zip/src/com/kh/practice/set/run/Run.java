package com.kh.practice.set.run;

import com.kh.practice.set.view.LotteryMenu;

public class Run {
	public static void main(String[] args) {
		new LotteryMenu().mainMenu();
	}
}
