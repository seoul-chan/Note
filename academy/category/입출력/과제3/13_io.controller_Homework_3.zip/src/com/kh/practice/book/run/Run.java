package com.kh.practice.book.run;

import com.kh.practice.book.view.BookMenu;

public class Run {
	public static void main(String[] args) {
		new BookMenu().mainMenu();
	}
}
