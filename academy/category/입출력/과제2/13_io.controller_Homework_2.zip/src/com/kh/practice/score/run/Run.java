package com.kh.practice.score.run;

import com.kh.practice.score.view.ScoreMenu;

public class Run {
	public static void main(String[] args) {
		new ScoreMenu().mainMenu();
	}
}
