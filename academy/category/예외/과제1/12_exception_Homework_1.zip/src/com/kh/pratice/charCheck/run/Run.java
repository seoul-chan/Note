package com.kh.pratice.charCheck.run;

import com.kh.pratice.charCheck.view.CharacterMenu;

public class Run {
	public static void main(String[] args) {
		new CharacterMenu().menu();
	}
}
