package com.kh.hw.member.run;

import com.kh.hw.memberview.MemberMenu;

public class Run {
	public static void main(String[] args) {
		MemberMenu mm = new MemberMenu();
		mm.maintMenu();
	}
}
